library(testthat)
library(ABCoptim)

test_check("ABCoptim")
