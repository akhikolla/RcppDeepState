
## ADMMsigma 2.1

 - Lots and lots of minor bug fixes
 
 - Added several (some modified) vignettes for clarity on the underlying algorithm and utility of the package (see the package [website](https://mgallow.github.io/ADMMsigma/))
 
 - Reversed the ADMM algorithm sequence -- which improves computation speed


## ADMMsigma 2.0

 - ADMMsigma is a major version release and total re-work of the original package.
 
 - Updates include further parallel computing capabilities, automatic selection of tuning parameter grid, and updated graphics. Many options for "ADMMsigma" have been added and/or re-named. Please refer to the manual for more detailed information.



