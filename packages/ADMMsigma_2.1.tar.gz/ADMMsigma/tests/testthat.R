library(testthat)
library(ADMMsigma)

test_check("ADMMsigma")
