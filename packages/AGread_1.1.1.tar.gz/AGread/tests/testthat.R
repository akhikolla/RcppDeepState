library(testthat)
library(AGread)

test_check("AGread")
