baseline <- function(...) UseMethod("baseline")
