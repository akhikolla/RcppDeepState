unpencoxIC <- function(...) UseMethod("unpencoxIC")
