#' @useDynLib ANN2, .registration=TRUE
#' @importFrom methods new
#' @import ggplot2 
#' @import reshape2 
#' @import Rcpp
NULL
