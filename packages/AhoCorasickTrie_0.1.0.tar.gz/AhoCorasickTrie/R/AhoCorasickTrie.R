#' AhoCorasickTrie: fast searching for multiple keywords in multiple texts
#'
#' @docType package
#' @name AhoCorasickTrie
#' @importFrom Rcpp evalCpp
#' @useDynLib AhoCorasickTrie
NULL
