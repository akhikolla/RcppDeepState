# AlphaPart 0.8.1
- we removed the relative partitions from the package, hence kept only absolute partitions (the option $abs or $rel now obsolete)
- parameter colAGV of the AlphaPart function changed to colBV