#' Run example in AlphaPart (see \code{\link[AlphaPart]{AlphaPart}}):

