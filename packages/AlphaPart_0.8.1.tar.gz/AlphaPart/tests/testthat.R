library(testthat)
library(AlphaPart)

test_check("AlphaPart")

