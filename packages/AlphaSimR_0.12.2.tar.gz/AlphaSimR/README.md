# README #

This package is currently under development. A manuscript detailing its use and the theory behind its operation is in preparation. 

'AlphaSimR' is available on both CRAN and Bitbucket. The most recent version will be on Bitbucket and it can be downloaded and installed using the 'devtools' library and the following command:
devtools::install_bitbucket("hickeyjohnteam/AlphaSimR")

Installing from Bitbucket requires the following libraries: 'R6', 'Rcpp', 'RcppArmadillo', and 'BH'.

