#ifndef _BayesComm_rtnorm_H
#define _BayesComm_rtnorm_H

#include <RcppArmadillo.h>

RcppExport SEXP rtnorm(SEXP N, SEXP MU, SEXP SI, SEXP LOW, SEXP UP) ;

#endif
