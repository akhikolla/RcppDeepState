#ifndef _BayesComm_rwish_H
#define _BayesComm_rwish_H

#include <RcppArmadillo.h>

RcppExport SEXP rwish(SEXP s, SEXP DF) ;

#endif
