#ifndef _BayesComm_sample_B_H
#define _BayesComm_sample_B_H

#include <RcppArmadillo.h>

RcppExport SEXP sample_B(SEXP Z, SEXP z) ;

#endif
