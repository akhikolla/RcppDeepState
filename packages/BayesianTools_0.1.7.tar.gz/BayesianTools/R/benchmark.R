# runBenchmark <- function(bayesianSetup, starvalues, particles){
#   
#   
#   # MCMC
#   testSampler <- mcmcSampler(bayesianSetup = bayesianSetup, startvalue = c(1,1,0), optimize = T)
#   testSampler2 <- getSamples(testSampler, 10000, DRlevels =2)
#   plot(testSampler2)
#   
#   
#   
#   
#   smcSampler
#   
#   
#   
#   
#   
# }