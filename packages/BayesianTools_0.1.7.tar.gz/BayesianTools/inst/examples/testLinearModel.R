x = c(1,2)
y = testLinearModel(x)
plot(y)
