#' @useDynLib abcADM, .registration = TRUE
#' @import Rcpp
#'
NULL
