library(testthat)
library(adeba)
test_check("adeba")
