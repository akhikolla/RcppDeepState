#' @references <https://github.com/Auburns/FastNoise>
#'
#' @useDynLib ambient
#' @importFrom Rcpp sourceCpp
#' @import rlang
'_PACKAGE'
