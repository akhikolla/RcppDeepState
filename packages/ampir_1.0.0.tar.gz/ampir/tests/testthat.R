library(testthat)
library(ampir)

test_check("ampir")
