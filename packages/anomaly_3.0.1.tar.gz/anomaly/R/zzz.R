
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Note - as of version 3.0.0 the anomaly_series function has been removed. Please use the (equivalent) capa.uv function instead.")
}
