#ifndef ___MEANVARANOMALY_H___
#define ___MEANVARANOMALY_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> MeanVarAnomaly(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP);


#endif  
