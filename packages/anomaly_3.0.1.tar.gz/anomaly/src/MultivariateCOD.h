#ifndef ___MULTIVARIATECOD_H___
#define ___MULTIVARIATECOD_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> MeanVarAnomalyMV(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);


#endif
