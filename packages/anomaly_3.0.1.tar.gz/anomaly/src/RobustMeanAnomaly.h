#ifndef ___ROBUSTMEANANOMALY_H___
#define ___ROBUSTMEANANOMALY_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> RobustMeanAnomaly(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP);


#endif  
