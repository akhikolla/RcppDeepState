
#ifndef ___ROBUSTMEANANOMALYMV_H___
#define ___ROBUSTMEANANOMALYMV_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> RobustMeanAnomalyMV(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);


#endif
