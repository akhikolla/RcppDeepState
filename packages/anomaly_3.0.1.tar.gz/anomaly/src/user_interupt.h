#ifndef ___USER_INTERUPT_H___
#define ___USER_INTERUPT_H___

struct user_interupt{};

#endif
