#ifndef __DISTANCE_L_HEADERS__

#define __DISTANCE_L_HEADERS__

SEXP CdistR(SEXP x,
	    SEXP sel,
	    SEXP smethod,
	    SEXP p);

#endif
