library(testthat)
library(aphid)

test_check("aphid")
