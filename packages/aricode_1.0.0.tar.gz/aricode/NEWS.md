
## aricode 1.0-0 (2020-06-23)

  -	added the Modified adjusted Rand Index
  -	added the Chi-Square statistics
  - bug fixed in SortPairs

## aricode 0.1-2	(2019-06-28)
  
  -	added the Adjusted Mutual information

## aricode 0.1-1	(2018-04-30)

  -	first submission to CRAN
