library(testthat)
library(aricode)
test_check("aricode")
