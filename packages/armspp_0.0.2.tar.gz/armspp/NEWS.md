# armspp 0.0.2

Remove dependency on `progress` to prevent a memory leak.

# armspp 0.0.1

This is the first release!
