#' @useDynLib armspp
#' @importFrom Rcpp sourceCpp
NULL
