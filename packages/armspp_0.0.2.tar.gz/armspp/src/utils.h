#include <Rcpp.h>

namespace armspp {

Rcpp::DottedPair listToDottedPair(Rcpp::List input, int index);

};
