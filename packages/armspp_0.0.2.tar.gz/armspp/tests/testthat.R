library(testthat)
library(armspp)

test_check('armspp')
