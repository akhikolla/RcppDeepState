library(testthat)
library(arrApply)

test_check("arrApply")
