coef.augSIMEX <- function (object, ...) 
{ return(object$coefficients)
}