vcov.augSIMEX <- function (object, ...) 
{ return(object$vcov)
}