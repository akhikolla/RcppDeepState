library(testthat)
library(baggr)

test_check("baggr")
