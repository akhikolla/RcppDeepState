library(testthat)
library(batman)

test_check("batman")
