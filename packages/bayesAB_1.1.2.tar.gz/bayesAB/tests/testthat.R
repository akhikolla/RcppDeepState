library(testthat)
library(bayesAB)

test_check("bayesAB")
