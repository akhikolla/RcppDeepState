# bayesbr
Beta Regression on a Bayesian Model <br>
#### For installing the package <br>
install.packages('devtools')<br>
Sys.setenv(R_REMOTES_NO_ERRORS_FROM_WARNINGS="true")<br>
devtools::install_github("pjoao266/bayesbr",auth_token = "4e74fa7982cb6868b26ffeb5156169c045b31af9", build = FALSE)<br>

