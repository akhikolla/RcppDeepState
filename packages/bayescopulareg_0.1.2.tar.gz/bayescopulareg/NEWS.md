# bayescopulareg 0.1.2

* Fixed a valgrind bug